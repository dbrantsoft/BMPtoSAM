com.dbsoft.bmptosam.bmptosam.PalMatch
com.dbsoft.bmptosam.bmptosam.PalArray
